# Self-host excalidraw on K8s.

## Prerequisites

- Envoy gateway installed and configured if using httproute